Go dummy file
